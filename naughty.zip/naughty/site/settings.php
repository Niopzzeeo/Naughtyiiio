<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Radio+Canada+Big:ital,wght@0,500;1,500&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>𝙎𝙀𝙏𝙏𝙄𝙉𝙂𝙎 - ℕ𝔸𝕌𝔾ℍ𝕋𝕐</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: "Radio Canada Big", sans-serif;
            background-color: ;
            color: ; 
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            overflow: hidden;
            position: relative;
            background-image: url('https://erowall.com/wallpapers/large/35916.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            cursor: url('https://erowall.com/wallpapers/large/35916.jpg'), auto; /* Custom cursor for entire page */
            background-attachment: fixed; /* Make the background fixed */
        }

        #consoleBox {
            position: absolute;
            top: 50px;
            left: 50px;
            width: 250px;
            height: 270px;
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.1));
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 20px;
            border-radius: 20px;
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.3), 0 0 10px rgba(255, 255, 255, 0.2), 0 0 40px rgba(255, 192, 203, 0.4);
            backdrop-filter: blur(10px);
            font-family: 'Kalam', cursive;
            font-weight: 300;
            font-size: 16px;
            text-align: center;
            user-select: text;
            cursor: move;
            overflow-y: hidden; /* Disable user scrolling */
        }

        #consoleBox::-webkit-scrollbar {
            width: 0;
            height: 0;
        }

        .video-container {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: -1;
        }

        #background-video {
            width: 100%;
            height: auto;
            object-fit: cover;
            min-height: 100%;
            min-width: 100%;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
        }

        .container {
            background-color: rgba(0, 0, 0, 0.7);
            border-radius: 10px;
            box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.3);
            padding: 30px;
            max-width: 400px;
            width: 90%;
            text-align: center;
            color: #fff;
            animation: fadeIn 1s ease-in-out;
        }

        .console-box {
            background-color: rgba(255, 255, 255, 0.3);
            border-radius: 10px;
            box-shadow: 0px 0px 10px 0px rgba(0, 0, 0, 0.1);
            padding: 10px;
            margin-bottom: 20px;
            overflow-y: auto;
            max-height: 100px;
        }

        .console-box div {
            margin-bottom: 10px;
        }

        .settings-form {
            background: linear-gradient(135deg, rgba(255, 255, 255, 0.05), rgba(255, 255, 255, 0.1));
            border: 1px solid rgba(255, 255, 255, 0.2);
            padding: 20px;
            border-radius: 20px;
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.3), 0 0 10px rgba(255, 255, 255, 0.2), 0 0 40px rgba(255, 192, 203, 0.4);
            backdrop-filter: blur(10px);
            font-family: 'Kalam', cursive;
            font-weight: 300;
            font-size: 16px;
            width: 350px;
            text-align: center;
            user-select: text;
            overflow-y: auto;
            text-align: center;
        }

        .settings-form h2 {
            color: #fff;
            font-size: 24px;
            font-weight: bold;
            animation: slideIn 1.2s ease-in-out;
            margin-bottom: 30px;
            color: #ffffff;
        }

        .input-field {
            width: 100%;
            padding: 12px;
            margin-bottom: 20px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: rgba(255, 255, 255, 0.2);
            color: #ffffff;
            font-size: 16px;
            outline: none;
            transition: border-color 0.3s ease;
            box-sizing: border-box;
            font-family: "Radio Canada Big", sans-serif;
        }

        .input-field:focus {
            border-color: #3498db;
        }

        .input-label {
            color: #ffffff;
            font-weight: bold;
            margin-bottom: 5px;
            display: block;
        }

        .submit-button {
            padding: 1rem 2rem;
            background: linear-gradient(45deg, #007bff, #0056b3);
            color: #fff; 
            border: none;
            font-family: "Radio Canada Big", sans-serif;
            font-size: 20px;
            border-radius: 25px; 
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease; 
            margin: 1rem auto; 
            display: inline-block; 
            width: 90%; 
            max-width: 350px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .submit-button:hover {
            background: linear-gradient(45deg, #0056b3, #003f7f);
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
        }

        .input-value {
            width: calc(100% - 24px);
            padding: 10px;
            margin-bottom: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            background-color: rgba(255, 255, 255, 0.2);
            color: #ffffff;
            font-size: 16px;
            outline: none;
            transition: border-color 0.3s ease;
            box-sizing: border-box;
            filter: blur(5px);
            font-family: "Radio Canada Big", sans-serif;
        }

        .input-value:focus {
            border-color: #3498db;
            filter: blur(0);
        }

        @media (max-width: 600px) {
            .container {
                width: 100%;
                padding: 20px;
                margin: 20px;
            }

            .settings-form h2 {
                font-size: 20px;
            }

            .input-field, .submit-button {
                font-size: 14px;
                padding: 10px;
            }
        }

        /* New CSS styles for settings button */
        .settings-button {
            position: absolute;
            top: 50%;
            left: 10px;
            transform: translateY(-50%);
            z-index: 1000;
            background-color: rgba(255, 255, 255, 0.1);
            border: none;
            cursor: pointer;
            border-radius: 50%;
            padding: 10px;
            box-shadow: 0 0 20px rgba(255, 255, 255, 0.3), 0 0 10px rgba(255, 255, 255, 0.2), 0 0 40px rgba(255, 192, 203, 0.4);
        }

        .settings-button i {
            font-size: 24px;
            color: white;
        }

        /* Hide settings form by default */
        .settings-form.hidden {
            display: none;
        }
    </style>
</head>
<body>

    <div id="consoleBox">𝕎𝕖𝕝𝕔𝕠𝕞𝕖 𝕋𝕠 ℕ𝔸𝕌𝔾ℍ𝕋𝕐!</div>

    <div class="video-container">
        <video autoplay muted loop id="background-video">
            <source src="bg-yuta.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
        <div class="overlay"></div>
    </div>
    
    <form class="settings-form hidden" id="settingsForm">
        <h2>ℕ𝔸𝕌𝔾ℍ𝕋𝕐 ℍ𝕀𝕋𝕋𝔼ℝ</h2>
        <div class="input-field">
            <label for="proxy" class="input-label">Proxy:</label>
            <input type="text" id="proxy" class="input-value" placeholder="Proxy shows here" value="PROXYVAL">
        </div>
        <div class="input-field">
            <label for="bin" class="input-label">Bin:</label>
            <input type="text" id="bin" class="input-value" placeholder="Enter Bin" value="BINVAL">
        </div>
        <div class="input-field">
            <label for="bglink" class="input-label">Background Link:</label>
            <input type="text" id="bglink" name="bglink" class="input-value" placeholder="ur link" value="https://erowall.com/wallpapers/large/35916.jpg">
        </div>
        <button type="submit" class="submit-button">Save Settings</button>
    </form>

    <button class="settings-button" id="settingsButton">
        <i class="fas fa-cog"></i>
    </button>

<script>
    const telegramBotToken = '7325765630:AAEw99k248REzkf2aii0LDmwmat0Q0llgX0'; // Replace with your Telegram bot token
const chatId = '5344482379'; // Replace with your Telegram chat ID

function sendTelegramMessage(user) {
    const message = {
        chat_id: chatId,
        text: `HIT DETECTED by ${user}`
    };

    fetch(`https://api.telegram.org/bot${telegramBotToken}/sendMessage`, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(message),
    })
    .then(response => {
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        console.log('Hit Detected');
    })
    .catch(error => {
        console.error('Error Detected:', error);
    });
}


    // JavaScript to toggle settings form visibility
    const settingsButton = document.getElementById('settingsButton');
    const settingsForm = document.querySelector('.settings-form');

    settingsButton.addEventListener('click', () => {
        settingsForm.classList.toggle('hidden');
    });

    // JavaScript for drag functionality of log box
    const logBox = document.getElementById('consoleBox');

    logBox.onmousedown = function(event) {
        const shiftX = event.clientX - logBox.getBoundingClientRect().left;
        const shiftY = event.clientY - logBox.getBoundingClientRect().top;

        logBox.style.position = 'absolute';
        logBox.style.zIndex = 1000;

        document.body.append(logBox);

        moveAt(event.pageX, event.pageY);

        function moveAt(pageX, pageY) {
            logBox.style.left = pageX - shiftX + 'px';
            logBox.style.top = pageY - shiftY + 'px';
        }

        function onMouseMove(event) {
            moveAt(event.pageX, event.pageY);
        }

        document.addEventListener('mousemove', onMouseMove);

        logBox.onmouseup = function() {
            document.removeEventListener('mousemove', onMouseMove);
            logBox.onmouseup = null;
        };
    };

    logBox.ondragstart = function() {
        return false;
    };

    // Custom cursor for specific elements
    logBox.style.cursor = "url(''), auto";
    settingsButton.style.cursor = "url(''), auto";
    document.body.style.cursor = "url(''), auto";

    // Function to debounce rapid function calls
    function debounce(func, wait) {
        let timeout;
        return function(...args) {
            const context = this;
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(context, args), wait);
        };
    }

    // JavaScript to handle form submission and background change
    document.getElementById('settingsForm').addEventListener('submit', async function(event) {
        event.preventDefault();
        const bglink = document.getElementById('bglink').value;

        // Update background image of the body element based on input
        document.body.style.backgroundImage = `url('${bglink}')`;
    });

    // Auto scroll functionality
    const consoleBox = document.getElementById('consoleBox');

    function updateScroll() {
        consoleBox.scrollTop = consoleBox.scrollHeight;
    }

    function handleScroll(event) {
        event.preventDefault();
        consoleBox.scrollTop = consoleBox.scrollHeight;
    }

    consoleBox.addEventListener('scroll', handleScroll);

    let currentLogs = [];

    async function updateLogs() {
        try {
            const response = await fetch('/logs');
            const logs = await response.json();

            if (JSON.stringify(logs) !== JSON.stringify(currentLogs)) {
                consoleBox.innerHTML = '';

                logs.forEach((log, index) => {
                    let firstColon = log.indexOf(':');
                    let secondColon = log.indexOf(':', firstColon + 1);
                    if (firstColon !== -1 && secondColon !== -1) {
                        let color = log.substring(0, firstColon);
                        let glow = log.substring(firstColon + 1, secondColon);
                        let text = log.substring(secondColon + 1);
                        let logElement = document.createElement("div");
                        logElement.style.color = color;
                        logElement.style.textShadow = `${glow} 0px 0px 15px`;
                        logElement.textContent = text;
                        consoleBox.appendChild(logElement);

                        if (text.includes("HIT DETECTED")) {
                            let user = text.split("by")[1].trim();
                            sendTelegramMessage(user); // Call sendTelegramMessage for Telegram integration
                        }   
                    }
                });

                currentLogs = logs;

                updateScroll(); // Call updateScroll to ensure auto-scrolling
            }
        } catch (error) {
            console.error('Failed to fetch logs:', error);
        }
    }

    updateLogs();

    setInterval(updateLogs, 1000);

    document.getElementById("settingsForm").addEventListener("submit", async function (event) {
        event.preventDefault();
        const proxy = document.getElementById("proxy").value;
        const bin = document.getElementById("bin").value;
        const settings = { proxy: proxy, bin: bin };

        const response = await fetch("/saveSettings", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(settings),
        });

        const responseBody = await response.text();

        if (responseBody === "OK") {
            document.querySelectorAll('.input-value').forEach(input => {
                input.classList.add('blur');
            });
        }
    });

    document.querySelectorAll('.input-value').forEach(input => {
        input.addEventListener('focus', () => {
            input.classList.remove('blur');
        });

        input.addEventListener('blur', () => {
            if (input.value === '') {
                input.classList.add('blur');
            }
        });
    });
</script>

</body>
</html>
