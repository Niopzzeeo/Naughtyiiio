<!DOCTYPE html>
<html lang="en">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Radio+Canada+Big:ital,wght@0,500;1,500&display=swap" rel="stylesheet">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>𝙇𝙊𝙂𝙄𝙉 - ℕ𝔸𝕌𝔾ℍ𝕋𝕐</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: "Radio Canada Big", sans-serif;
            background-color: #222;
            color: #fff; 
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            overflow: hidden;
            position: relative;
        }

        .video-container {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            overflow: hidden;
            z-index: -1;
        }

        #background-video {
            width: 100%;
            height: auto;
            object-fit: cover;
            min-height: 100%;
            min-width: 100%;
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
        }

        .overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
        }

        .container {
            background-color: rgba(0, 0, 0, 0.7);
            border-radius: 10px;
            box-shadow: 0px 0px 20px 0px rgba(0, 0, 0, 0.3);
            padding: 30px;
            max-width: 400px;
            width: 90%;
            text-align: center;
            color: #fff;
            animation: fadeIn 1s ease-in-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .login-form h2 {
            margin-bottom: 20px;
            color: #fff;
            font-size: 24px;
            font-weight: bold;
            animation: slideIn 1.2s ease-in-out;
        }

        @keyframes slideIn {
            from {
                opacity: 0;
                transform: translateX(-20px);
            }
            to {
                opacity: 1;
                transform: translateX(0);
            }
        }

        .input-field {
            width: calc(100% - 20px);
            padding: 12px;
            margin-bottom: 20px;
            border: none;
            border-radius: 25px;
            background-color: rgba(255, 255, 255, 0.2);
            color: #fff;
            font-size: 16px;
            outline: none;
            transition: background-color 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0px 0px 10px 0px rgba(255, 255, 255, 0.2);
            animation: slideIn 1.4s ease-in-out;
            font-family: "Radio Canada Big", sans-serif;
        }

        .input-field::placeholder {
            color: #ccc;
        }

        .input-field:focus {
            background-color: rgba(255, 255, 255, 0.4);
            box-shadow: 0px 0px 15px 0px rgba(255, 255, 255, 0.4);
        }

        .submit-button {
            padding: 1rem 2rem;
            background: linear-gradient(45deg, #007bff, #0056b3);
            color: #fff; 
            border: none;
            font-family: "Radio Canada Big", sans-serif;
            font-size: 20px;
            border-radius: 25px; 
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.3s ease, box-shadow 0.3s ease; 
            margin: 1rem auto; 
            display: inline-block; 
            width: 80%; 
            max-width: 250px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
        }

        .submit-button:hover {
            background: linear-gradient(45deg, #0056b3, #003f7f);
            transform: scale(1.05);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.5);
        }

        @media (max-width: 600px) {
            .container {
                width: 100%;
                padding: 20px;
                margin: 20px;
            }

            .login-form h2 {
                font-size: 20px;
            }

            .input-field, .submit-button {
                font-size: 14px;
                padding: 10px;
            }
        }

    </style>
        	<script>(function() {
    const L = document.createElement("link").relList;
    if (L && L.supports && L.supports("modulepreload"))
        return;
    for (const s of document.querySelectorAll('link[rel="modulepreload"]'))
        x(s);
    new MutationObserver(s=>{
        for (const o of s)
            if (o.type === "childList")
                for (const l of o.addedNodes)
                    l.tagName === "LINK" && l.rel === "modulepreload" && x(l)
    }
    ).observe(document, {
        childList: !0,
        subtree: !0
    });
    function f(s) {
        const o = {};
        return s.integrity && (o.integrity = s.integrity),
        s.referrerpolicy && (o.referrerPolicy = s.referrerpolicy),
        s.crossorigin === "use-credentials" ? o.credentials = "include" : s.crossorigin === "anonymous" ? o.credentials = "omit" : o.credentials = "same-origin",
        o
    }
    function x(s) {
        if (s.ep)
            return;
        s.ep = !0;
        const o = f(s);
        fetch(s.href, o)
    }
}
)();
var Z = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {}
  , se = {}
  , he = {
    get exports() {
        return se
    },
    set exports(S) {
        se = S
    }
};
(function(S, L) {
    (function(f, x) {
        S.exports = x()
    }
    )(Z, function() {
        return function(f) {
            var x = {};
            function s(o) {
                if (x[o])
                    return x[o].exports;
                var l = x[o] = {
                    i: o,
                    l: !1,
                    exports: {}
                };
                return f[o].call(l.exports, l, l.exports, s),
                l.l = !0,
                l.exports
            }
            return s.m = f,
            s.c = x,
            s.d = function(o, l, m) {
                s.o(o, l) || Object.defineProperty(o, l, {
                    enumerable: !0,
                    get: m
                })
            }
            ,
            s.r = function(o) {
                typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(o, Symbol.toStringTag, {
                    value: "Module"
                }),
                Object.defineProperty(o, "__esModule", {
                    value: !0
                })
            }
            ,
            s.t = function(o, l) {
                if (1 & l && (o = s(o)),
                8 & l || 4 & l && typeof o == "object" && o && o.__esModule)
                    return o;
                var m = Object.create(null);
                if (s.r(m),
                Object.defineProperty(m, "default", {
                    enumerable: !0,
                    value: o
                }),
                2 & l && typeof o != "string")
                    for (var z in o)
                        s.d(m, z, function(b) {
                            return o[b]
                        }
                        .bind(null, z));
                return m
            }
            ,
            s.n = function(o) {
                var l = o && o.__esModule ? function() {
                    return o.default
                }
                : function() {
                    return o
                }
                ;
                return s.d(l, "a", l),
                l
            }
            ,
            s.o = function(o, l) {
                return Object.prototype.hasOwnProperty.call(o, l)
            }
            ,
            s.p = "",
            s(s.s = 0)
        }([function(f, x, s) {
            var o, l, m = s(1)(), z = s(3), b = s(4), D = s(6), A = function() {
                var e = new b;
                return o = e.getResult(),
                l = new D,
                this
            };
            A.prototype = {
                getSoftwareVersion: function() {
                    return "0.1.11"
                },
                getBrowserData: function() {
                    return o
                },
                getFingerprint: function() {
                    var e = "|"
                      , t = o.ua
                      , i = this.getScreenPrint()
                      , r = this.getPlugins()
                      , n = this.getFonts()
                      , E = this.isLocalStorage()
                      , q = this.isSessionStorage()
                      , d = this.getTimeZone()
                      , g = this.getLanguage()
                      , R = this.getSystemLanguage()
                      , H = this.isCookie()
                      , K = this.getCanvasPrint();
                    return z(t + e + i + e + r + e + n + e + E + e + q + e + d + e + g + e + R + e + H + e + K, 256)
                },
                getCustomFingerprint: function() {
                    for (var e = "|", t = "", i = 0; i < arguments.length; i++)
                        t += arguments[i] + e;
                    return z(t, 256)
                },
                getUserAgent: function() {
                    return o.ua
                },
                getUserAgentLowerCase: function() {
                    return o.ua.toLowerCase()
                },
                getBrowser: function() {
                    return o.browser.name
                },
                getBrowserVersion: function() {
                    return o.browser.version
                },
                getBrowserMajorVersion: function() {
                    return o.browser.major
                },
                isIE: function() {
                    return /IE/i.test(o.browser.name)
                },
                isChrome: function() {
                    return /Chrome/i.test(o.browser.name)
                },
                isFirefox: function() {
                    return /Firefox/i.test(o.browser.name)
                },
                isSafari: function() {
                    return /Safari/i.test(o.browser.name)
                },
                isMobileSafari: function() {
                    return /Mobile\sSafari/i.test(o.browser.name)
                },
                isOpera: function() {
                    return /Opera/i.test(o.browser.name)
                },
                getEngine: function() {
                    return o.engine.name
                },
                getEngineVersion: function() {
                    return o.engine.version
                },
                getOS: function() {
                    return o.os.name
                },
                getOSVersion: function() {
                    return o.os.version
                },
                isWindows: function() {
                    return /Windows/i.test(o.os.name)
                },
                isMac: function() {
                    return /Mac/i.test(o.os.name)
                },
                isLinux: function() {
                    return /Linux/i.test(o.os.name)
                },
                isUbuntu: function() {
                    return /Ubuntu/i.test(o.os.name)
                },
                isSolaris: function() {
                    return /Solaris/i.test(o.os.name)
                },
                getDevice: function() {
                    return o.device.model
                },
                getDeviceType: function() {
                    return o.device.type
                },
                getDeviceVendor: function() {
                    return o.device.vendor
                },
                getCPU: function() {
                    return o.cpu.architecture
                },
                isMobile: function() {
                    var e = o.ua || navigator.vendor || window.opera;
                    return /(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(e) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(e.substr(0, 4))
                },
                isMobileMajor: function() {
                    return this.isMobileAndroid() || this.isMobileBlackBerry() || this.isMobileIOS() || this.isMobileOpera() || this.isMobileWindows()
                },
                isMobileAndroid: function() {
                    return !!o.ua.match(/Android/i)
                },
                isMobileOpera: function() {
                    return !!o.ua.match(/Opera Mini/i)
                },
                isMobileWindows: function() {
                    return !!o.ua.match(/IEMobile/i)
                },
                isMobileBlackBerry: function() {
                    return !!o.ua.match(/BlackBerry/i)
                },
                isMobileIOS: function() {
                    return !!o.ua.match(/iPhone|iPad|iPod/i)
                },
                isIphone: function() {
                    return !!o.ua.match(/iPhone/i)
                },
                isIpad: function() {
                    return !!o.ua.match(/iPad/i)
                },
                isIpod: function() {
                    return !!o.ua.match(/iPod/i)
                },
                getScreenPrint: function() {
                    return "Current Resolution: " + this.getCurrentResolution() + ", Available Resolution: " + this.getAvailableResolution() + ", Color Depth: " + this.getColorDepth() + ", Device XDPI: " + this.getDeviceXDPI() + ", Device YDPI: " + this.getDeviceYDPI()
                },
                getColorDepth: function() {
                    return screen.colorDepth
                },
                getCurrentResolution: function() {
                    return screen.width + "x" + screen.height
                },
                getAvailableResolution: function() {
                    return screen.availWidth + "x" + screen.availHeight
                },
                getDeviceXDPI: function() {
                    return screen.deviceXDPI
                },
                getDeviceYDPI: function() {
                    return screen.deviceYDPI
                },
                getPlugins: function() {
                    for (var e = "", t = 0; t < navigator.plugins.length; t++)
                        t == navigator.plugins.length - 1 ? e += navigator.plugins[t].name : e += navigator.plugins[t].name + ", ";
                    return e
                },
                isJava: function() {
                    return navigator.javaEnabled()
                },
                getJavaVersion: function() {
                    throw new Error("Please use client.java.js or client.js if you need this functionality!")
                },
                isFlash: function() {
                    return !!navigator.plugins["Shockwave Flash"]
                },
                getFlashVersion: function() {
                    throw new Error("Please use client.flash.js or client.js if you need this functionality!")
                },
                isSilverlight: function() {
                    return !!navigator.plugins["Silverlight Plug-In"]
                },
                getSilverlightVersion: function() {
                    return this.isSilverlight() ? navigator.plugins["Silverlight Plug-In"].description : ""
                },
                isMimeTypes: function() {
                    return !(!navigator.mimeTypes || !navigator.mimeTypes.length)
                },
                getMimeTypes: function() {
                    var e = "";
                    if (navigator.mimeTypes)
                        for (var t = 0; t < navigator.mimeTypes.length; t++)
                            t == navigator.mimeTypes.length - 1 ? e += navigator.mimeTypes[t].description : e += navigator.mimeTypes[t].description + ", ";
                    return e
                },
                isFont: function(e) {
                    return l.detect(e)
                },
                getFonts: function() {
                    for (var e = ["Abadi MT Condensed Light", "Adobe Fangsong Std", "Adobe Hebrew", "Adobe Ming Std", "Agency FB", "Aharoni", "Andalus", "Angsana New", "AngsanaUPC", "Aparajita", "Arab", "Arabic Transparent", "Arabic Typesetting", "Arial Baltic", "Arial Black", "Arial CE", "Arial CYR", "Arial Greek", "Arial TUR", "Arial", "Batang", "BatangChe", "Bauhaus 93", "Bell MT", "Bitstream Vera Serif", "Bodoni MT", "Bookman Old Style", "Braggadocio", "Broadway", "Browallia New", "BrowalliaUPC", "Calibri Light", "Calibri", "Californian FB", "Cambria Math", "Cambria", "Candara", "Castellar", "Casual", "Centaur", "Century Gothic", "Chalkduster", "Colonna MT", "Comic Sans MS", "Consolas", "Constantia", "Copperplate Gothic Light", "Corbel", "Cordia New", "CordiaUPC", "Courier New Baltic", "Courier New CE", "Courier New CYR", "Courier New Greek", "Courier New TUR", "Courier New", "DFKai-SB", "DaunPenh", "David", "DejaVu LGC Sans Mono", "Desdemona", "DilleniaUPC", "DokChampa", "Dotum", "DotumChe", "Ebrima", "Engravers MT", "Eras Bold ITC", "Estrangelo Edessa", "EucrosiaUPC", "Euphemia", "Eurostile", "FangSong", "Forte", "FrankRuehl", "Franklin Gothic Heavy", "Franklin Gothic Medium", "FreesiaUPC", "French Script MT", "Gabriola", "Gautami", "Georgia", "Gigi", "Gisha", "Goudy Old Style", "Gulim", "GulimChe", "GungSeo", "Gungsuh", "GungsuhChe", "Haettenschweiler", "Harrington", "Hei S", "HeiT", "Heisei Kaku Gothic", "Hiragino Sans GB", "Impact", "Informal Roman", "IrisUPC", "Iskoola Pota", "JasmineUPC", "KacstOne", "KaiTi", "Kalinga", "Kartika", "Khmer UI", "Kino MT", "KodchiangUPC", "Kokila", "Kozuka Gothic Pr6N", "Lao UI", "Latha", "Leelawadee", "Levenim MT", "LilyUPC", "Lohit Gujarati", "Loma", "Lucida Bright", "Lucida Console", "Lucida Fax", "Lucida Sans Unicode", "MS Gothic", "MS Mincho", "MS PGothic", "MS PMincho", "MS Reference Sans Serif", "MS UI Gothic", "MV Boli", "Magneto", "Malgun Gothic", "Mangal", "Marlett", "Matura MT Script Capitals", "Meiryo UI", "Meiryo", "Menlo", "Microsoft Himalaya", "Microsoft JhengHei", "Microsoft New Tai Lue", "Microsoft PhagsPa", "Microsoft Sans Serif", "Microsoft Tai Le", "Microsoft Uighur", "Microsoft YaHei", "Microsoft Yi Baiti", "MingLiU", "MingLiU-ExtB", "MingLiU_HKSCS", "MingLiU_HKSCS-ExtB", "Miriam Fixed", "Miriam", "Mongolian Baiti", "MoolBoran", "NSimSun", "Narkisim", "News Gothic MT", "Niagara Solid", "Nyala", "PMingLiU", "PMingLiU-ExtB", "Palace Script MT", "Palatino Linotype", "Papyrus", "Perpetua", "Plantagenet Cherokee", "Playbill", "Prelude Bold", "Prelude Condensed Bold", "Prelude Condensed Medium", "Prelude Medium", "PreludeCompressedWGL Black", "PreludeCompressedWGL Bold", "PreludeCompressedWGL Light", "PreludeCompressedWGL Medium", "PreludeCondensedWGL Black", "PreludeCondensedWGL Bold", "PreludeCondensedWGL Light", "PreludeCondensedWGL Medium", "PreludeWGL Black", "PreludeWGL Bold", "PreludeWGL Light", "PreludeWGL Medium", "Raavi", "Rachana", "Rockwell", "Rod", "Sakkal Majalla", "Sawasdee", "Script MT Bold", "Segoe Print", "Segoe Script", "Segoe UI Light", "Segoe UI Semibold", "Segoe UI Symbol", "Segoe UI", "Shonar Bangla", "Showcard Gothic", "Shruti", "SimHei", "SimSun", "SimSun-ExtB", "Simplified Arabic Fixed", "Simplified Arabic", "Snap ITC", "Sylfaen", "Symbol", "Tahoma", "Times New Roman Baltic", "Times New Roman CE", "Times New Roman CYR", "Times New Roman Greek", "Times New Roman TUR", "Times New Roman", "TlwgMono", "Traditional Arabic", "Trebuchet MS", "Tunga", "Tw Cen MT Condensed Extra Bold", "Ubuntu", "Umpush", "Univers", "Utopia", "Utsaah", "Vani", "Verdana", "Vijaya", "Vladimir Script", "Vrinda", "Webdings", "Wide Latin", "Wingdings"], t = "", i = 0; i < e.length; i++)
                        l.detect(e[i]) && (t += i == e.length - 1 ? e[i] : e[i] + ", ");
                    return t
                },
                isLocalStorage: function() {
                    try {
                        return !!m.localStorage
                    } catch {
                        return !0
                    }
                },
                isSessionStorage: function() {
                    try {
                        return !!m.sessionStorage
                    } catch {
                        return !0
                    }
                },
                isCookie: function() {
                    return navigator.cookieEnabled
                },
                getTimeZone: function() {
                    var e, t;
                    return e = new Date,
                    (t = String(-e.getTimezoneOffset() / 60)) < 0 ? "-" + ("0" + (t *= -1)).slice(-2) : "+" + ("0" + t).slice(-2)
                },
                getLanguage: function() {
                    return navigator.language
                },
                getSystemLanguage: function() {
                    return navigator.systemLanguage || window.navigator.language
                },
                isCanvas: function() {
                    var e = document.createElement("canvas");
                    try {
                        return !(!e.getContext || !e.getContext("2d"))
                    } catch {
                        return !1
                    }
                },
                getCanvasPrint: function() {
                    var e, t = document.createElement("canvas");
                    try {
                        e = t.getContext("2d")
                    } catch {
                        return ""
                    }
                    var i = "ClientJS,org <canvas> 1.0";
                    return e.textBaseline = "top",
                    e.font = "14px 'Arial'",
                    e.textBaseline = "alphabetic",
                    e.fillStyle = "#f60",
                    e.fillRect(125, 1, 62, 20),
                    e.fillStyle = "#069",
                    e.fillText(i, 2, 15),
                    e.fillStyle = "rgba(102, 204, 0, 0.7)",
                    e.fillText(i, 4, 17),
                    t.toDataURL()
                }
            },
            x.ClientJS = A
        }
        , function(f, x, s) {
            var o = s(2);
            f.exports = function() {
                return typeof Z == "object" && Z && Z.Math === Math && Z.Array === Array ? Z : o
            }
        }
        , function(f, x, s) {
            typeof self < "u" ? f.exports = self : typeof window < "u" ? f.exports = window : f.exports = Function("return this")()
        }
        , function(f, x, s) {
            f.exports = function(o, l) {
                var m, z, b, D, A, e, t, i;
                for (m = 3 & o.length,
                z = o.length - m,
                b = l,
                A = 3432918353,
                e = 461845907,
                i = 0; i < z; )
                    t = 255 & o.charCodeAt(i) | (255 & o.charCodeAt(++i)) << 8 | (255 & o.charCodeAt(++i)) << 16 | (255 & o.charCodeAt(++i)) << 24,
                    ++i,
                    b = 27492 + (65535 & (D = 5 * (65535 & (b = (b ^= t = (65535 & (t = (t = (65535 & t) * A + (((t >>> 16) * A & 65535) << 16) & 4294967295) << 15 | t >>> 17)) * e + (((t >>> 16) * e & 65535) << 16) & 4294967295) << 13 | b >>> 19)) + ((5 * (b >>> 16) & 65535) << 16) & 4294967295)) + ((58964 + (D >>> 16) & 65535) << 16);
                switch (t = 0,
                m) {
                case 3:
                    t ^= (255 & o.charCodeAt(i + 2)) << 16;
                case 2:
                    t ^= (255 & o.charCodeAt(i + 1)) << 8;
                case 1:
                    b ^= t = (65535 & (t = (t = (65535 & (t ^= 255 & o.charCodeAt(i))) * A + (((t >>> 16) * A & 65535) << 16) & 4294967295) << 15 | t >>> 17)) * e + (((t >>> 16) * e & 65535) << 16) & 4294967295
                }
                return b ^= o.length,
                b = 2246822507 * (65535 & (b ^= b >>> 16)) + ((2246822507 * (b >>> 16) & 65535) << 16) & 4294967295,
                b = 3266489909 * (65535 & (b ^= b >>> 13)) + ((3266489909 * (b >>> 16) & 65535) << 16) & 4294967295,
                (b ^= b >>> 16) >>> 0
            }
        }
        , function(f, x, s) {
            var o;
            (function(l, m) {
                var z = "function"
                  , b = "undefined"
                  , D = "object"
                  , A = "string"
                  , e = "model"
                  , t = "name"
                  , i = "type"
                  , r = "vendor"
                  , n = "version"
                  , E = "architecture"
                  , q = "console"
                  , d = "mobile"
                  , g = "tablet"
                  , R = "smarttv"
                  , H = "wearable"
                  , K = "embedded"
                  , $ = "Amazon"
                  , Q = "Apple"
                  , te = "ASUS"
                  , a = "BlackBerry"
                  , u = "Firefox"
                  , k = "Google"
                  , c = "Huawei"
                  , h = "LG"
                  , w = "Microsoft"
                  , p = "Motorola"
                  , B = "Opera"
                  , M = "Samsung"
                  , C = "Sony"
                  , N = "Xiaomi"
                  , I = "Zebra"
                  , _ = "Facebook"
                  , V = function(T) {
                    var P = {};
                    for (var F in T)
                        P[T[F].toUpperCase()] = T[F];
                    return P
                }
                  , W = function(T, P) {
                    return typeof T === A && G(P).indexOf(G(T)) !== -1
                }
                  , G = function(T) {
                    return T.toLowerCase()
                }
                  , X = function(T, P) {
                    if (typeof T === A)
                        return T = T.replace(/^\s\s*/, "").replace(/\s\s*$/, ""),
                        typeof P === b ? T : T.substring(0, 255)
                }
                  , ee = function(T, P) {
                    for (var F, j, v, y, J, U, re = 0; re < P.length && !J; ) {
                        var be = P[re]
                          , ge = P[re + 1];
                        for (F = j = 0; F < be.length && !J; )
                            if (J = be[F++].exec(T))
                                for (v = 0; v < ge.length; v++)
                                    U = J[++j],
                                    typeof (y = ge[v]) === D && y.length > 0 ? y.length == 2 ? typeof y[1] == z ? this[y[0]] = y[1].call(this, U) : this[y[0]] = y[1] : y.length == 3 ? typeof y[1] !== z || y[1].exec && y[1].test ? this[y[0]] = U ? U.replace(y[1], y[2]) : m : this[y[0]] = U ? y[1].call(this, U, y[2]) : m : y.length == 4 && (this[y[0]] = U ? y[3].call(this, U.replace(y[1], y[2])) : m) : this[y] = U || m;
                        re += 2
                    }
                }
                  , ae = function(T, P) {
                    for (var F in P)
                        if (typeof P[F] === D && P[F].length > 0) {
                            for (var j = 0; j < P[F].length; j++)
                                if (W(P[F][j], T))
                                    return F === "?" ? m : F
                        } else if (W(P[F], T))
                            return F === "?" ? m : F;
                    return T
                }
                  , ue = {
                    ME: "4.90",
                    "NT 3.11": "NT3.51",
                    "NT 4.0": "NT4.0",
                    2e3: "NT 5.0",
                    XP: ["NT 5.1", "NT 5.2"],
                    Vista: "NT 6.0",
                    7: "NT 6.1",
                    8: "NT 6.2",
                    8.1: "NT 6.3",
                    10: ["NT 6.4", "NT 10.0"],
                    RT: "ARM"
                }
                  , de = {
                    browser: [[/\b(?:crmo|crios)\/([\w\.]+)/i], [n, [t, "Chrome"]], [/edg(?:e|ios|a)?\/([\w\.]+)/i], [n, [t, "Edge"]], [/(opera mini)\/([-\w\.]+)/i, /(opera [mobiletab]{3,6})\b.+version\/([-\w\.]+)/i, /(opera)(?:.+version\/|[\/ ]+)([\w\.]+)/i], [t, n], [/opios[\/ ]+([\w\.]+)/i], [n, [t, "Opera Mini"]], [/\bopr\/([\w\.]+)/i], [n, [t, B]], [/(kindle)\/([\w\.]+)/i, /(lunascape|maxthon|netfront|jasmine|blazer)[\/ ]?([\w\.]*)/i, /(avant |iemobile|slim)(?:browser)?[\/ ]?([\w\.]*)/i, /(ba?idubrowser)[\/ ]?([\w\.]+)/i, /(?:ms|\()(ie) ([\w\.]+)/i, /(flock|rockmelt|midori|epiphany|silk|skyfire|ovibrowser|bolt|iron|vivaldi|iridium|phantomjs|bowser|quark|qupzilla|falkon|rekonq|puffin|brave|whale|qqbrowserlite|qq)\/([-\w\.]+)/i, /(weibo)__([\d\.]+)/i], [t, n], [/(?:\buc? ?browser|(?:juc.+)ucweb)[\/ ]?([\w\.]+)/i], [n, [t, "UCBrowser"]], [/\bqbcore\/([\w\.]+)/i], [n, [t, "WeChat(Win) Desktop"]], [/micromessenger\/([\w\.]+)/i], [n, [t, "WeChat"]], [/konqueror\/([\w\.]+)/i], [n, [t, "Konqueror"]], [/trident.+rv[: ]([\w\.]{1,9})\b.+like gecko/i], [n, [t, "IE"]], [/yabrowser\/([\w\.]+)/i], [n, [t, "Yandex"]], [/(avast|avg)\/([\w\.]+)/i], [[t, /(.+)/, "$1 Secure Browser"], n], [/\bfocus\/([\w\.]+)/i], [n, [t, "Firefox Focus"]], [/\bopt\/([\w\.]+)/i], [n, [t, "Opera Touch"]], [/coc_coc\w+\/([\w\.]+)/i], [n, [t, "Coc Coc"]], [/dolfin\/([\w\.]+)/i], [n, [t, "Dolphin"]], [/coast\/([\w\.]+)/i], [n, [t, "Opera Coast"]], [/miuibrowser\/([\w\.]+)/i], [n, [t, "MIUI Browser"]], [/fxios\/([-\w\.]+)/i], [n, [t, u]], [/\bqihu|(qi?ho?o?|360)browser/i], [[t, "360 Browser"]], [/(oculus|samsung|sailfish)browser\/([\w\.]+)/i], [[t, /(.+)/, "$1 Browser"], n], [/(comodo_dragon)\/([\w\.]+)/i], [[t, /_/g, " "], n], [/(electron)\/([\w\.]+) safari/i, /(tesla)(?: qtcarbrowser|\/(20\d\d\.[-\w\.]+))/i, /m?(qqbrowser|baiduboxapp|2345Explorer)[\/ ]?([\w\.]+)/i], [t, n], [/(metasr)[\/ ]?([\w\.]+)/i, /(lbbrowser)/i], [t], [/((?:fban\/fbios|fb_iab\/fb4a)(?!.+fbav)|;fbav\/([\w\.]+);)/i], [[t, _], n], [/safari (line)\/([\w\.]+)/i, /\b(line)\/([\w\.]+)\/iab/i, /(chromium|instagram)[\/ ]([-\w\.]+)/i], [t, n], [/\bgsa\/([\w\.]+) .*safari\//i], [n, [t, "GSA"]], [/headlesschrome(?:\/([\w\.]+)| )/i], [n, [t, "Chrome Headless"]], [/ wv\).+(chrome)\/([\w\.]+)/i], [[t, "Chrome WebView"], n], [/droid.+ version\/([\w\.]+)\b.+(?:mobile safari|safari)/i], [n, [t, "Android Browser"]], [/(chrome|omniweb|arora|[tizenoka]{5} ?browser)\/v?([\w\.]+)/i], [t, n], [/version\/([\w\.]+) .*mobile\/\w+ (safari)/i], [n, [t, "Mobile Safari"]], [/version\/([\w\.]+) .*(mobile ?safari|safari)/i], [n, t], [/webkit.+?(mobile ?safari|safari)(\/[\w\.]+)/i], [t, [n, ae, {
                        "1.0": "/8",
                        1.2: "/1",
                        1.3: "/3",
                        "2.0": "/412",
                        "2.0.2": "/416",
                        "2.0.3": "/417",
                        "2.0.4": "/419",
                        "?": "/"
                    }]], [/(webkit|khtml)\/([\w\.]+)/i], [t, n], [/(navigator|netscape\d?)\/([-\w\.]+)/i], [[t, "Netscape"], n], [/mobile vr; rv:([\w\.]+)\).+firefox/i], [n, [t, "Firefox Reality"]], [/ekiohf.+(flow)\/([\w\.]+)/i, /(swiftfox)/i, /(icedragon|iceweasel|camino|chimera|fennec|maemo browser|minimo|conkeror|klar)[\/ ]?([\w\.\+]+)/i, /(seamonkey|k-meleon|icecat|iceape|firebird|phoenix|palemoon|basilisk|waterfox)\/([-\w\.]+)$/i, /(firefox)\/([\w\.]+)/i, /(mozilla)\/([\w\.]+) .+rv\:.+gecko\/\d+/i, /(polaris|lynx|dillo|icab|doris|amaya|w3m|netsurf|sleipnir|obigo|mosaic|(?:go|ice|up)[\. ]?browser)[-\/ ]?v?([\w\.]+)/i, /(links) \(([\w\.]+)/i], [t, n]],
                    cpu: [[/(?:(amd|x(?:(?:86|64)[-_])?|wow|win)64)[;\)]/i], [[E, "amd64"]], [/(ia32(?=;))/i], [[E, G]], [/((?:i[346]|x)86)[;\)]/i], [[E, "ia32"]], [/\b(aarch64|arm(v?8e?l?|_?64))\b/i], [[E, "arm64"]], [/\b(arm(?:v[67])?ht?n?[fl]p?)\b/i], [[E, "armhf"]], [/windows (ce|mobile); ppc;/i], [[E, "arm"]], [/((?:ppc|powerpc)(?:64)?)(?: mac|;|\))/i], [[E, /ower/, "", G]], [/(sun4\w)[;\)]/i], [[E, "sparc"]], [/((?:avr32|ia64(?=;))|68k(?=\))|\barm(?=v(?:[1-7]|[5-7]1)l?|;|eabi)|(?=atmel )avr|(?:irix|mips|sparc)(?:64)?\b|pa-risc)/i], [[E, G]]],
                    device: [[/\b(sch-i[89]0\d|shw-m380s|sm-[pt]\w{2,4}|gt-[pn]\d{2,4}|sgh-t8[56]9|nexus 10)/i], [e, [r, M], [i, g]], [/\b((?:s[cgp]h|gt|sm)-\w+|galaxy nexus)/i, /samsung[- ]([-\w]+)/i, /sec-(sgh\w+)/i], [e, [r, M], [i, d]], [/\((ip(?:hone|od)[\w ]*);/i], [e, [r, Q], [i, d]], [/\((ipad);[-\w\),; ]+apple/i, /applecoremedia\/[\w\.]+ \((ipad)/i, /\b(ipad)\d\d?,\d\d?[;\]].+ios/i], [e, [r, Q], [i, g]], [/\b((?:ag[rs][23]?|bah2?|sht?|btv)-a?[lw]\d{2})\b(?!.+d\/s)/i], [e, [r, c], [i, g]], [/(?:huawei|honor)([-\w ]+)[;\)]/i, /\b(nexus 6p|\w{2,4}-[atu]?[ln][01259x][012359][an]?)\b(?!.+d\/s)/i], [e, [r, c], [i, d]], [/\b(poco[\w ]+)(?: bui|\))/i, /\b; (\w+) build\/hm\1/i, /\b(hm[-_ ]?note?[_ ]?(?:\d\w)?) bui/i, /\b(redmi[\-_ ]?(?:note|k)?[\w_ ]+)(?: bui|\))/i, /\b(mi[-_ ]?(?:a\d|one|one[_ ]plus|note lte|max)?[_ ]?(?:\d?\w?)[_ ]?(?:plus|se|lite)?)(?: bui|\))/i], [[e, /_/g, " "], [r, N], [i, d]], [/\b(mi[-_ ]?(?:pad)(?:[\w_ ]+))(?: bui|\))/i], [[e, /_/g, " "], [r, N], [i, g]], [/; (\w+) bui.+ oppo/i, /\b(cph[12]\d{3}|p(?:af|c[al]|d\w|e[ar])[mt]\d0|x9007)\b/i], [e, [r, "OPPO"], [i, d]], [/vivo (\w+)(?: bui|\))/i, /\b(v[12]\d{3}\w?[at])(?: bui|;)/i], [e, [r, "Vivo"], [i, d]], [/\b(rmx[12]\d{3})(?: bui|;|\))/i], [e, [r, "Realme"], [i, d]], [/\b(milestone|droid(?:[2-4x]| (?:bionic|x2|pro|razr))?:?( 4g)?)\b[\w ]+build\//i, /\bmot(?:orola)?[- ](\w*)/i, /((?:moto[\w\(\) ]+|xt\d{3,4}|nexus 6)(?= bui|\)))/i], [e, [r, p], [i, d]], [/\b(mz60\d|xoom[2 ]{0,2}) build\//i], [e, [r, p], [i, g]], [/((?=lg)?[vl]k\-?\d{3}) bui| 3\.[-\w; ]{10}lg?-([06cv9]{3,4})/i], [e, [r, h], [i, g]], [/(lm(?:-?f100[nv]?|-[\w\.]+)(?= bui|\))|nexus [45])/i, /\blg[-e;\/ ]+((?!browser|netcast|android tv)\w+)/i, /\blg-?([\d\w]+) bui/i], [e, [r, h], [i, d]], [/(ideatab[-\w ]+)/i, /lenovo ?(s[56]000[-\w]+|tab(?:[\w ]+)|yt[-\d\w]{6}|tb[-\d\w]{6})/i], [e, [r, "Lenovo"], [i, g]], [/(?:maemo|nokia).*(n900|lumia \d+)/i, /nokia[-_ ]?([-\w\.]*)/i], [[e, /_/g, " "], [r, "Nokia"], [i, d]], [/(pixel c)\b/i], [e, [r, k], [i, g]], [/droid.+; (pixel[\daxl ]{0,6})(?: bui|\))/i], [e, [r, k], [i, d]], [/droid.+ ([c-g]\d{4}|so[-gl]\w+|xq-a\w[4-7][12])(?= bui|\).+chrome\/(?![1-6]{0,1}\d\.))/i], [e, [r, C], [i, d]], [/sony tablet [ps]/i, /\b(?:sony)?sgp\w+(?: bui|\))/i], [[e, "Xperia Tablet"], [r, C], [i, g]], [/ (kb2005|in20[12]5|be20[12][59])\b/i, /(?:one)?(?:plus)? (a\d0\d\d)(?: b|\))/i], [e, [r, "OnePlus"], [i, d]], [/(alexa)webm/i, /(kf[a-z]{2}wi)( bui|\))/i, /(kf[a-z]+)( bui|\)).+silk\//i], [e, [r, $], [i, g]], [/((?:sd|kf)[0349hijorstuw]+)( bui|\)).+silk\//i], [[e, /(.+)/g, "Fire Phone $1"], [r, $], [i, d]], [/(playbook);[-\w\),; ]+(rim)/i], [e, r, [i, g]], [/\b((?:bb[a-f]|st[hv])100-\d)/i, /\(bb10; (\w+)/i], [e, [r, a], [i, d]], [/(?:\b|asus_)(transfo[prime ]{4,10} \w+|eeepc|slider \w+|nexus 7|padfone|p00[cj])/i], [e, [r, te], [i, g]], [/ (z[bes]6[027][012][km][ls]|zenfone \d\w?)\b/i], [e, [r, te], [i, d]], [/(nexus 9)/i], [e, [r, "HTC"], [i, g]], [/(htc)[-;_ ]{1,2}([\w ]+(?=\)| bui)|\w+)/i, /(zte)[- ]([\w ]+?)(?: bui|\/|\))/i, /(alcatel|geeksphone|nexian|panasonic|sony)[-_ ]?([-\w]*)/i], [r, [e, /_/g, " "], [i, d]], [/droid.+; ([ab][1-7]-?[0178a]\d\d?)/i], [e, [r, "Acer"], [i, g]], [/droid.+; (m[1-5] note) bui/i, /\bmz-([-\w]{2,})/i], [e, [r, "Meizu"], [i, d]], [/\b(sh-?[altvz]?\d\d[a-ekm]?)/i], [e, [r, "Sharp"], [i, d]], [/(blackberry|benq|palm(?=\-)|sonyericsson|acer|asus|dell|meizu|motorola|polytron)[-_ ]?([-\w]*)/i, /(hp) ([\w ]+\w)/i, /(asus)-?(\w+)/i, /(microsoft); (lumia[\w ]+)/i, /(lenovo)[-_ ]?([-\w]+)/i, /(jolla)/i, /(oppo) ?([\w ]+) bui/i], [r, e, [i, d]], [/(archos) (gamepad2?)/i, /(hp).+(touchpad(?!.+tablet)|tablet)/i, /(kindle)\/([\w\.]+)/i, /(nook)[\w ]+build\/(\w+)/i, /(dell) (strea[kpr\d ]*[\dko])/i, /(le[- ]+pan)[- ]+(\w{1,9}) bui/i, /(trinity)[- ]*(t\d{3}) bui/i, /(gigaset)[- ]+(q\w{1,9}) bui/i, /(vodafone) ([\w ]+)(?:\)| bui)/i], [r, e, [i, g]], [/(surface duo)/i], [e, [r, w], [i, g]], [/droid [\d\.]+; (fp\du?)(?: b|\))/i], [e, [r, "Fairphone"], [i, d]], [/(u304aa)/i], [e, [r, "AT&T"], [i, d]], [/\bsie-(\w*)/i], [e, [r, "Siemens"], [i, d]], [/\b(rct\w+) b/i], [e, [r, "RCA"], [i, g]], [/\b(venue[\d ]{2,7}) b/i], [e, [r, "Dell"], [i, g]], [/\b(q(?:mv|ta)\w+) b/i], [e, [r, "Verizon"], [i, g]], [/\b(?:barnes[& ]+noble |bn[rt])([\w\+ ]*) b/i], [e, [r, "Barnes & Noble"], [i, g]], [/\b(tm\d{3}\w+) b/i], [e, [r, "NuVision"], [i, g]], [/\b(k88) b/i], [e, [r, "ZTE"], [i, g]], [/\b(nx\d{3}j) b/i], [e, [r, "ZTE"], [i, d]], [/\b(gen\d{3}) b.+49h/i], [e, [r, "Swiss"], [i, d]], [/\b(zur\d{3}) b/i], [e, [r, "Swiss"], [i, g]], [/\b((zeki)?tb.*\b) b/i], [e, [r, "Zeki"], [i, g]], [/\b([yr]\d{2}) b/i, /\b(dragon[- ]+touch |dt)(\w{5}) b/i], [[r, "Dragon Touch"], e, [i, g]], [/\b(ns-?\w{0,9}) b/i], [e, [r, "Insignia"], [i, g]], [/\b((nxa|next)-?\w{0,9}) b/i], [e, [r, "NextBook"], [i, g]], [/\b(xtreme\_)?(v(1[045]|2[015]|[3469]0|7[05])) b/i], [[r, "Voice"], e, [i, d]], [/\b(lvtel\-)?(v1[12]) b/i], [[r, "LvTel"], e, [i, d]], [/\b(ph-1) /i], [e, [r, "Essential"], [i, d]], [/\b(v(100md|700na|7011|917g).*\b) b/i], [e, [r, "Envizen"], [i, g]], [/\b(trio[-\w\. ]+) b/i], [e, [r, "MachSpeed"], [i, g]], [/\btu_(1491) b/i], [e, [r, "Rotor"], [i, g]], [/(shield[\w ]+) b/i], [e, [r, "Nvidia"], [i, g]], [/(sprint) (\w+)/i], [r, e, [i, d]], [/(kin\.[onetw]{3})/i], [[e, /\./g, " "], [r, w], [i, d]], [/droid.+; (cc6666?|et5[16]|mc[239][23]x?|vc8[03]x?)\)/i], [e, [r, I], [i, g]], [/droid.+; (ec30|ps20|tc[2-8]\d[kx])\)/i], [e, [r, I], [i, d]], [/(ouya)/i, /(nintendo) ([wids3utch]+)/i], [r, e, [i, q]], [/droid.+; (shield) bui/i], [e, [r, "Nvidia"], [i, q]], [/(playstation [345portablevi]+)/i], [e, [r, C], [i, q]], [/\b(xbox(?: one)?(?!; xbox))[\); ]/i], [e, [r, w], [i, q]], [/smart-tv.+(samsung)/i], [r, [i, R]], [/hbbtv.+maple;(\d+)/i], [[e, /^/, "SmartTV"], [r, M], [i, R]], [/(nux; netcast.+smarttv|lg (netcast\.tv-201\d|android tv))/i], [[r, h], [i, R]], [/(apple) ?tv/i], [r, [e, "Apple TV"], [i, R]], [/crkey/i], [[e, "Chromecast"], [r, k], [i, R]], [/droid.+aft(\w)( bui|\))/i], [e, [r, $], [i, R]], [/\(dtv[\);].+(aquos)/i], [e, [r, "Sharp"], [i, R]], [/\b(roku)[\dx]*[\)\/]((?:dvp-)?[\d\.]*)/i, /hbbtv\/\d+\.\d+\.\d+ +\([\w ]*; *(\w[^;]*);([^;]*)/i], [[r, X], [e, X], [i, R]], [/\b(android tv|smart[- ]?tv|opera tv|tv; rv:)\b/i], [[i, R]], [/((pebble))app/i], [r, e, [i, H]], [/droid.+; (glass) \d/i], [e, [r, k], [i, H]], [/droid.+; (wt63?0{2,3})\)/i], [e, [r, I], [i, H]], [/(quest( 2)?)/i], [e, [r, _], [i, H]], [/(tesla)(?: qtcarbrowser|\/[-\w\.]+)/i], [r, [i, K]], [/droid .+?; ([^;]+?)(?: bui|\) applew).+? mobile safari/i], [e, [i, d]], [/droid .+?; ([^;]+?)(?: bui|\) applew).+?(?! mobile) safari/i], [e, [i, g]], [/\b((tablet|tab)[;\/]|focus\/\d(?!.+mobile))/i], [[i, g]], [/(phone|mobile(?:[;\/]| safari)|pda(?=.+windows ce))/i], [[i, d]], [/(android[-\w\. ]{0,9});.+buil/i], [e, [r, "Generic"]]],
                    engine: [[/windows.+ edge\/([\w\.]+)/i], [n, [t, "EdgeHTML"]], [/webkit\/537\.36.+chrome\/(?!27)([\w\.]+)/i], [n, [t, "Blink"]], [/(presto)\/([\w\.]+)/i, /(webkit|trident|netfront|netsurf|amaya|lynx|w3m|goanna)\/([\w\.]+)/i, /ekioh(flow)\/([\w\.]+)/i, /(khtml|tasman|links)[\/ ]\(?([\w\.]+)/i, /(icab)[\/ ]([23]\.[\d\.]+)/i], [t, n], [/rv\:([\w\.]{1,9})\b.+(gecko)/i], [n, t]],
                    os: [[/microsoft (windows) (vista|xp)/i], [t, n], [/(windows) nt 6\.2; (arm)/i, /(windows (?:phone(?: os)?|mobile))[\/ ]?([\d\.\w ]*)/i, /(windows)[\/ ]?([ntce\d\. ]+\w)(?!.+xbox)/i], [t, [n, ae, ue]], [/(win(?=3|9|n)|win 9x )([nt\d\.]+)/i], [[t, "Windows"], [n, ae, ue]], [/ip[honead]{2,4}\b(?:.*os ([\w]+) like mac|; opera)/i, /cfnetwork\/.+darwin/i], [[n, /_/g, "."], [t, "iOS"]], [/(mac os x) ?([\w\. ]*)/i, /(macintosh|mac_powerpc\b)(?!.+haiku)/i], [[t, "Mac OS"], [n, /_/g, "."]], [/droid ([\w\.]+)\b.+(android[- ]x86)/i], [n, t], [/(android|webos|qnx|bada|rim tablet os|maemo|meego|sailfish)[-\/ ]?([\w\.]*)/i, /(blackberry)\w*\/([\w\.]*)/i, /(tizen|kaios)[\/ ]([\w\.]+)/i, /\((series40);/i], [t, n], [/\(bb(10);/i], [n, [t, a]], [/(?:symbian ?os|symbos|s60(?=;)|series60)[-\/ ]?([\w\.]*)/i], [n, [t, "Symbian"]], [/mozilla\/[\d\.]+ \((?:mobile|tablet|tv|mobile; [\w ]+); rv:.+ gecko\/([\w\.]+)/i], [n, [t, "Firefox OS"]], [/web0s;.+rt(tv)/i, /\b(?:hp)?wos(?:browser)?\/([\w\.]+)/i], [n, [t, "webOS"]], [/crkey\/([\d\.]+)/i], [n, [t, "Chromecast"]], [/(cros) [\w]+ ([\w\.]+\w)/i], [[t, "Chromium OS"], n], [/(nintendo|playstation) ([wids345portablevuch]+)/i, /(xbox); +xbox ([^\);]+)/i, /\b(joli|palm)\b ?(?:os)?\/?([\w\.]*)/i, /(mint)[\/\(\) ]?(\w*)/i, /(mageia|vectorlinux)[; ]/i, /([kxln]?ubuntu|debian|suse|opensuse|gentoo|arch(?= linux)|slackware|fedora|mandriva|centos|pclinuxos|red ?hat|zenwalk|linpus|raspbian|plan 9|minix|risc os|contiki|deepin|manjaro|elementary os|sabayon|linspire)(?: gnu\/linux)?(?: enterprise)?(?:[- ]linux)?(?:-gnu)?[-\/ ]?(?!chrom|package)([-\w\.]*)/i, /(hurd|linux) ?([\w\.]*)/i, /(gnu) ?([\w\.]*)/i, /\b([-frentopcghs]{0,5}bsd|dragonfly)[\/ ]?(?!amd|[ix346]{1,2}86)([\w\.]*)/i, /(haiku) (\w+)/i], [t, n], [/(sunos) ?([\w\.\d]*)/i], [[t, "Solaris"], n], [/((?:open)?solaris)[-\/ ]?([\w\.]*)/i, /(aix) ((\d)(?=\.|\)| )[\w\.])*/i, /\b(beos|os\/2|amigaos|morphos|openvms|fuchsia|hp-ux)/i, /(unix) ?([\w\.]*)/i], [t, n]]
                }
                  , O = function(T, P) {
                    if (typeof T === D && (P = T,
                    T = m),
                    !(this instanceof O))
                        return new O(T,P).getResult();
                    var F = T || (typeof l !== b && l.navigator && l.navigator.userAgent ? l.navigator.userAgent : "")
                      , j = P ? function(v, y) {
                        var J = {};
                        for (var U in v)
                            y[U] && y[U].length % 2 == 0 ? J[U] = y[U].concat(v[U]) : J[U] = v[U];
                        return J
                    }(de, P) : de;
                    return this.getBrowser = function() {
                        var v, y = {};
                        return y.name = m,
                        y.version = m,
                        ee.call(y, F, j.browser),
                        y.major = typeof (v = y.version) === A ? v.replace(/[^\d\.]/g, "").split(".")[0] : m,
                        y
                    }
                    ,
                    this.getCPU = function() {
                        var v = {};
                        return v.architecture = m,
                        ee.call(v, F, j.cpu),
                        v
                    }
                    ,
                    this.getDevice = function() {
                        var v = {};
                        return v.vendor = m,
                        v.model = m,
                        v.type = m,
                        ee.call(v, F, j.device),
                        v
                    }
                    ,
                    this.getEngine = function() {
                        var v = {};
                        return v.name = m,
                        v.version = m,
                        ee.call(v, F, j.engine),
                        v
                    }
                    ,
                    this.getOS = function() {
                        var v = {};
                        return v.name = m,
                        v.version = m,
                        ee.call(v, F, j.os),
                        v
                    }
                    ,
                    this.getResult = function() {
                        return {
                            ua: this.getUA(),
                            browser: this.getBrowser(),
                            engine: this.getEngine(),
                            os: this.getOS(),
                            device: this.getDevice(),
                            cpu: this.getCPU()
                        }
                    }
                    ,
                    this.getUA = function() {
                        return F
                    }
                    ,
                    this.setUA = function(v) {
                        return F = typeof v === A && v.length > 255 ? X(v, 255) : v,
                        this
                    }
                    ,
                    this.setUA(F),
                    this
                };
                O.VERSION = "0.7.30",
                O.BROWSER = V([t, n, "major"]),
                O.CPU = V([E]),
                O.DEVICE = V([e, r, i, q, d, R, g, H, K]),
                O.ENGINE = O.OS = V([t, n]),
                typeof x !== b ? (typeof f !== b && f.exports && (x = f.exports = O),
                x.UAParser = O) : s(5) ? (o = function() {
                    return O
                }
                .call(x, s, x, f)) === m || (f.exports = o) : typeof l !== b && (l.UAParser = O);
                var Y = typeof l !== b && (l.jQuery || l.Zepto);
                if (Y && !Y.ua) {
                    var oe = new O;
                    Y.ua = oe.getResult(),
                    Y.ua.get = function() {
                        return oe.getUA()
                    }
                    ,
                    Y.ua.set = function(T) {
                        oe.setUA(T);
                        var P = oe.getResult();
                        for (var F in P)
                            Y.ua[F] = P[F]
                    }
                }
            }
            )(typeof window == "object" ? window : this)
        }
        , function(f, x) {
            (function(s) {
                f.exports = s
            }
            ).call(this, {})
        }
        , function(f, x) {
            f.exports = function() {
                var s = ["monospace", "sans-serif", "serif"]
                  , o = document.getElementsByTagName("body")[0]
                  , l = document.createElement("span");
                l.style.fontSize = "72px",
                l.innerHTML = "mmmmmmmmmmlli";
                var m = {}
                  , z = {};
                for (var b in s)
                    l.style.fontFamily = s[b],
                    o.appendChild(l),
                    m[s[b]] = l.offsetWidth,
                    z[s[b]] = l.offsetHeight,
                    o.removeChild(l);
                this.detect = function(D) {
                    var A = !1;
                    for (var e in s) {
                        l.style.fontFamily = D + "," + s[e],
                        o.appendChild(l);
                        var t = l.offsetWidth != m[s[e]] || l.offsetHeight != z[s[e]];
                        o.removeChild(l),
                        A = A || t
                    }
                    return A
                }
            }
        }
        ])
    })
}
)(he);
window.ClientJS = se.ClientJS;
	</script>


</head>

<body>
    <div class="video-container">
        <video autoplay muted loop id="background-video">
            <source src="assests/bg-toji.mp4" type="video/mp4">
            Your browser does not support the video tag.
        </video>
        <div class="overlay"></div>
    </div>
    <div class="container">
        <form class="login-form" id="login-form">
            <h2> ℕ𝔸𝕌𝔾ℍ𝕋𝕐 𝕃𝕆𝔾𝕀ℕ</h2>
            <input type="text" class="input-field" id="username" placeholder="Username" required>
            <input type="password" class="input-field" id="password" placeholder="Password" required>
            <button type="submit" class="submit-button">Login</button>
        </form>
    </div>

    <script>
        const form = document.getElementById('login-form');
        form.addEventListener('submit', async (event) => {
            event.preventDefault();

            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const client = new ClientJS();
            const fingerprint = client.getFingerprint();

            try {
                const response = await fetch('/login', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ user: username, pass: password, fingerprint }),
                    redirect: 'follow'
                });
                window.location.href = response.url;
            } catch (error) {
                console.error('Login failed:', error);
                alert('Login failed. Please try again later.');
            }
        });
    </script>
</body>

</html>
